# Blog-App-Django-1.-11
This is the simple blog created using Django 1.11
